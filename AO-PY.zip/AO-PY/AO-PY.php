<?php
/*
Plugin Name: AO-PY
Plugin URI:	https://github.com/ldoubil/AO-py
Description:  爱国Ao第三方扩展！。
Version: 5.2.0
Author: 会做饭的二哈
Author URI: mailto:baikaiwen12@outlook.com
License: A "Slug" license name e.g. GPL2
*/



require (plugin_dir_path(__FILE__) .'/plugin-update-checker/plugin-update-checker.php');
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://raw.githubusercontent.com/ldoubil/AO-py/master/updata.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'AO-py'
);

include(plugin_dir_path(__FILE__) .'./config.php'); //导入配置文件
// print_r($AO_config->$menu_function);

global $wpdb, $wp_query;
$aoconfig = get_option('AOPUCONFIG');   //取到配置
register_activation_hook( __FILE__, 'AOPY_install' );//插件安装配置


add_action('admin_menu','addmenu'); //插入菜单
add_action('wp_head', 'addjq');     //挂载addjq

if (get_option('AOPYCONFIG')[0][0]=='true') {                //是否启用功能1
    add_action('wp_head', 'addapp1');    //挂载功能1
}
if (get_option('AOPYCONFIG')[1][0]=='true') {                //是否启用功能2
    add_action('wp_head', 'addapp2');    //挂载功能2
}
if (get_option('AOPYCONFIG')[2][0]=='true') {                //是否启用功能3
    add_action('wp_head', 'addapp3');    //挂载功能3
}
if (get_option('AOPYCONFIG')[3][0]=='true') {                //是否启用功能4
    add_action('wp_head', 'addapp4');    //挂载功能4
}
if (get_option('AOPYCONFIG')[4][0]=='true') {                //是否启用功能5
    add_action('wp_head', 'addapp5');    //挂载功能5
}



//------------------------------------------------------------------------
function AOPY_install(){                        //默认配置
    global $wpdb, $wp_query;
    $pyconfig = array(
        array("false",""), //首页标签默认关闭
        array("false",""),//app2开关 和内容
        array("false",""),
        array("false",""),//鹊桥功能
        array("false","400"),//看板娘
     );

     update_option('AOPYCONFIG',$pyconfig); //添加ao设置
}
//------------------------------------------------------------------------
function addmenu()                                   //插入菜单的位置和信息配置        
{
    global $wpdb, $wp_query;
    global $AO_config;
    add_options_page(
        $AO_config['menu_title'],
        $AO_config['menu_title'],
        $AO_config['menu_capability'], 
        $AO_config['menu_slug'],
        $AO_config['menu_function']);

}
//-------------------------------------------------------------------------
function menutext(){            //菜单内容

$sd = file_get_contents("https://raw.githubusercontent.com/ldoubil/AO-py/master/sq.txt");
$asa = explode(" ",$sd);
$asd=0;
foreach($asa as $value){
    if ($_SERVER['HTTP_HOST']==$value) {
       $asd=1;
       break;
    }

   }
   if ($asd!=1)//如果域名不是adcc.me
   {
echo ("<h1>您的域名未授权，请联系购买正版产品！<br>联系1806190090@qq.com</h1>");}else {
    echo ("<h4>您的域名已授权。</h4>");
   include(plugin_dir_path(__FILE__) . './CaiDan.php');
}
    
}

//后面的就是挂载jq
//--------------------------------------------------------------------------
function addjq(){                   //引入jq代码
    echo('<script src="'.plugin_dir_url(__FILE__).'/js/JQ.js"></script>');
    echo('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css"/>');//外链
}

//--------------------------------------------------------------------------
function addapp1(){
    // includes_url($path, $scheme)
    if (is_single()) {
        
    }else{
        include(plugin_dir_path(__FILE__ ).'/includes/app1.php');
		
    }
    // 只有首页才进行修改操作
    // echo('<script src="'."></script>');

}
//---------------------------------------------------------------------------
function addapp2(){
    // includes_url($path, $scheme)
    if (is_single()) {
        include(plugin_dir_path(__FILE__ ).'/includes/app2.php');
    }else {
        // 哦对了不是文章页面不做操作
    }
    
    // echo('<script src="'."></script>');

}
//---------------------------------------------------------------------------
function addapp3(){
    // includes_url($path, $scheme)
    if (is_single()) {
        include(plugin_dir_path(__FILE__ ).'/includes/app3.php');
    }else {
        // 哦对了不是文章页面不做操作
    }
    
    // echo('<script src="'."></script>');

}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
function addapp4(){
    // includes_url($path, $scheme)
    if (is_single()) {
        include(plugin_dir_path(__FILE__ ).'/includes/app4.php');
    }else {
        // 哦对了不是文章页面不做操作
    }

}
//---------------------------------------------------------------------------
function addapp5(){
    // includes_url($path, $scheme)
   
        include(plugin_dir_path(__FILE__ ).'/includes/app5.php');
   

}
//---------------------------------------------------------------------------


function AOpyajax()
{
    global $wpdb, $wp_query;

    wp_die();
    
}
//不过还是别管这段了，万一我啥时候用；





//保存设置
function AOAJAX(){
    global $wpdb, $wp_query;
    $da = get_option('AOPUCONFIG');
    $da[0][0]=$_GET['app1'];
    $da[0][1]=$_GET['app1_A'];

    $da[1][0]=$_GET['app2'];
    $da[1][1]=$_GET['app2_A'];

    $da[2][0]=$_GET['app3'];
    $da[2][1]="";

    $da[3][0]=$_GET['app4'];
    $da[3][1]=$_GET['app4_A'];

    $da[4][0]=$_GET['app5'];
    $da[4][1]=$_GET['app5_A'];
    
    update_option('AOPYCONFIG', $da);
    echo("ojbk");
    wp_die();
}

add_action('wp_ajax_AO-PY', 'AOAJAX'); //admin权限
add_action('wp_ajax_nopriv_AOpyajax', 'AOpyajax');
add_action('wp_ajax_AOpyajax', 'AOpyajax');