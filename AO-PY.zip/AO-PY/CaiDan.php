<?php print_r(get_option('AOPUCONFIG'))?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>AO配置界面</title>
  <script src=" <?php echo(plugin_dir_url(__FILE__)) ?>/js/JQ.js"></script>
  <script src=" <?php echo(plugin_dir_url(__FILE__)) ?>/js/py.js"></script>
  <link rel="stylesheet" href=" <?php echo(plugin_dir_url(__FILE__)) ?>/css/foundation.min.css">
  <script src=" <?php echo(plugin_dir_url(__FILE__)) ?>/js/foundation.min.js" charset="utf-8"></script>
  <script src=" <?php echo(plugin_dir_url(__FILE__)) ?>/js/modernizr.js" charset="utf-8"></script>
  <link rel="stylesheet" href=" <?php echo(plugin_dir_url(__FILE__)) ?>/css/DanDan.css">
  <style>
    .ula {
      margin-left: 0;
    }
  </style>
  <script>
    $(function () {
      $('ul').addClass("ula");
    })

    // 判断是否为手机函数
    function IsPhone() {
      mobile_flag = false;
      var screen_width = window.screen.width;
      var screen_height = window.screen.height;
      if (screen_width < 500 && screen_height < 820) {
        mobile_flag = true;
      }
      return mobile_flag;
    }
    // ---------------------------------------------------------------------------------

// __________________________________________________________________________________________
  </script>
</head>

<body>


  <!-- 菜单栏 -->

  <div style=" margin-top: 20px;margin-right: 20px;">
    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="panel radius">
      <h4>首页模块关键词美化</H4>
      <div class="switch">
        <input id="app1" type="checkbox" <?php echo(get_option('AOPYCONFIG')[0][0]=='true' ?'checked':''); ?>>
        <label for="app1"></label>
      </div>
      附加Style：
      <input id="app1_A" type="text" value="<?php echo(get_option('AOPYCONFIG')[0][1]); ?>">
    </div>
    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="panel radius">
    规则 =》用户名：rgb(0,0,0);用户名：rgb(,,,) =》多个用户用;隔开   
      <H4>会员评论颜色</H4>
      <div class="switch">
        <input id="app2" type="checkbox" <?php echo(get_option('AOPYCONFIG')[1][0]=='true' ?'checked':''); ?>>
        <label for="app2"></label>
      </div>
      用户组颜色规则：
      <input id="app2_A" type="text" value="<?php echo(get_option('AOPYCONFIG')[1][1]); ?>">
    </div>
    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="panel radius">
      <H4>作者名片美化</H4>
      <div class="switch">
        <input id="app3" type="checkbox" <?php echo(get_option('AOPYCONFIG')[2][0]=='true'?'checked':''); ?>>
        <label for="app3"></label>
      </div>
    </div>
    <!-- ------------------------------------------------------------------------------------------------------------- -->

    <div class="panel radius">
      <H4>《鹊桥！》</H4>
      <div class="switch">
        <input id="app4" type="checkbox" <?php echo(get_option('AOPYCONFIG')[3][0]=='true' ?'checked':''); ?>>
        <label for="app4"></label>
      </div>
        <h4>鹊桥附属功能1:</h4>
            首页预览图智能修复
        <div class="switch">
            <input id="app6" type="checkbox" <?php echo(get_option('AOPYCONFIG')[5][0]=='true' ?'checked':''); ?>>
            <label for="app6"></label>
        </div>
      鹊桥脚本资讯QQ.
      鹊桥远程地址：
      <input id="app4_A" type="text" value="<?php echo(get_option('AOPYCONFIG')[3][1]); ?>">

    </div>
    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="panel radius">
      <H4>看板娘</H4>
      <div class="switch">
        <input id="app5" type="checkbox" <?php echo(get_option('AOPYCONFIG')[4][0]=='true' ?'checked':''); ?>>
        <label for="app5"></label>
      </div>
      看板娘大小（默认400）：
      看板娘详细修改QQ咨询这个设置很多无需做成功能了！
      <input id="app5_A" type="text" value="<?php echo(get_option('AOPYCONFIG')[4][1]); ?>">
    </div>
    <!-- ------------------------------------------------------------------------------------------------------------- -->



    <div>
      <button onclick="bc()" type="button" class="button expand" style="
    padding-bottom: 20px;
    padding-top: 1px;">保存配置</button>





      <script>

        function bc() {
          // alert("执行！");
          $.get('<?php echo( admin_url( "admin-ajax.php" )) ?>', 'action=AO-PY' +
            '&app1=' + $('#app1').prop("checked") + '&app1_A=' + $('#app1_A').val() +
            '&app2=' + $('#app2').prop("checked") + '&app2_A=' + $('#app2_A').val() +
            '&app3=' + $('#app3').prop("checked") +
            '&app4=' + $('#app4').prop("checked") + '&app4_A=' + $('#app4_A').val() +
            '&app5=' + $('#app5').prop("checked") + '&app5_A=' + $('#app5_A').val() +
            '&app6=' +$('#app6').prop("checked"),
            function (data) {
              alert("保存完毕");
            }
          );
        }
      </script>



</body>