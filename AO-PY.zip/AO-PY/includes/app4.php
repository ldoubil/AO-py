<script>


    function queq() {
        alert('启动修复成功！')
        $("[onclick='queq()']").remove();
        var dataa = 0;
        $('.inn-singular__post__body__content,.inn-content-reseter').find('img').attr('alt','图片利用鹊桥加载中....请等待')
        $('.inn-singular__post__body__content,.inn-content-reseter').find('img').each(
            function () {
                $.get("<?php echo(get_option('AOPYCONFIG')[3][1]);?>",
                    'url=' + $(this).attr('src'),
                    function (data) {
                        var a = new Array();
                        a = data.split("**********");
                        $("[src='"+a[0]+"']").attr('src',a[1]);
                        dataa = data
                    }
                );
               
            })

    }





    $(function () {
        var qq = '<div onclick="queq()" class="inn-report inn-singular__post__footer__item"><div class="inn-report__btn__container"><a class="inn-report__btn"><span class="far fa-eye" aria-hidden="true"></span><span class="poi-icon__text"> 启动鹊桥修复图片</span></a></div></div>';

        $('#inn-report').before(qq);

    })

</script>