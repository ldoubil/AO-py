<script>

function app6_J(){
    $('inn-homebox__item__thumbnail__container,' +
        '.inn-card_post-thumbnail__item__thumbnail__container,' +
        '.inn-card__thumbnail__container,' +
        '.inn-card__thumbnail__container_post-thumbnail')
        .find("img").each(
        function () {
            A = $(this).attr("src"); //现在的图片地址
            B = $(this).attr("data-src");//要求的图片地址

            if (A != B){
                //如果不等于执行修改
                $(this).attr("src","");
                $(this).attr("alt","停止加载，开始自动修复！");
                //开启自动修复
                $.get("<?php echo(get_option('AOPYCONFIG')[3][1]);?>",
                    'url=' + $(this).attr('data-src'),
                    function (data) {
                        var a = new Array();
                        a = data.split("**********");
                        $("[data-src='"+a[0]+"']").attr('src',a[1]);
                    });

            }else{
                //等于的话就不进行修复但是我打算预留一下留着统计修复次数！后期开发说不定。。
            }
        }
    );

}
$(function () {
    setTimeout(app6_J,5000);
})

</script>