<?php

$AO_config = array(
    'menu_title'      =>  'AO-PY配置'      ,
    'menu_capability' =>  'manage_options' ,
    'menu_slug'       =>  'ao-config'      ,
    'menu_function'   =>  'menutext'

 );