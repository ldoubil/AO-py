
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月18日</h3>
        <p>
           APP2内容添加中。
           <br>
           经验条
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月11日18:38:50</h3>
        <p>
           开始构思APP2；
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月11日18:36:07</h3>
        <p>
            优化了APP1的加载优先和加载速度。
            <br>
            废弃了api获取配置，改用wordpress内置函数。
            <br>
            到此为止APP1（主页标签优化），功能到此停止开发，往后只修改BUG。
            <br>
            开启新功能APP2(用户组评论颜色)。
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月9日13:42:21</h3>
        <p>
            由于换了新的框架我又看了半天文档，不过好在还是更换完了。<br>所以我要去打个飞机冷静下。
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月9日</h3>
        <p>
            更换新的ui
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月8日</h3>
        <p>优化功能1的细节</p>

    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <h3 class="layui-timeline-title">2019年7月7日</h3>
        <p>
            开启项目
        </p>
    </div>
</li>
<!-- ======================================================================================== -->
<li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis"></i>
    <div class="layui-timeline-content layui-text">
        <div class="layui-timeline-title">起源</div>
    </div>
</li>
<!-- ======================================================================================== -->